package com.upendra.Admin.dto;

public class AdminDto {

}
