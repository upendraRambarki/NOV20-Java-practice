package com.upendra.Admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdminMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
